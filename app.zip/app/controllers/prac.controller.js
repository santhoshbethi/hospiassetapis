exports.prac= (req, res) => {
  res.status(200).send("first execution.");
};