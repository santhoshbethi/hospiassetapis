module.exports = (sequelize, Sequelize) => {
	const Login = sequelize.define("login", {
    id: {
      type: Sequelize.INTEGER,
	  primaryKey: true
    },
    email: {
      type: Sequelize.STRING
    },
    password: {
      type: Sequelize.STRING
    }
  });
  return Login;
};
 
 


